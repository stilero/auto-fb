DROP TABLE IF EXISTS `#__autofbook_log`;
DROP TABLE IF EXISTS `#__autofbook_queue`;
